var mongoose = require("mongoose");
var Post = require("./models/posts");
var Comment = require("./models/comment");
var data = [
	{
		name: "Welcome to my Website", 
	 author: "Owner of this Website.", 
	 link:"https://wdbapp3.run-ap-south1.goorm.io/posts/new", 
	 description:"Welcome Everybody to my Website... Come Here Everybody and share your feelings with the whole world through POSTS."},
	{
		name: "Thank You for inviting me!", 
	 author: "Siddharth Kumar.", 
	 link:"https://www.google.com/", 
	 description:"Thank You for inviting me in this posts app."
	},
	{
		name: "Thank You for inviting me!", 
	 author: "Praveen Kumar.", 
	 link:"https://www.youtube.com", 
	 description:"Thank You for inviting me in this posts app."},
]
function seedDB(){
Post.remove({}, function(err){
	if(err){
		console.log(err)
	}
	console.log("removed posts!");
		data.forEach(function(seed){
	    Post.create(seed, function(err,post){
			if(err){
				console.log(err);
			}else{
				console.log("added a post");
			}
		});
	});
});
}
module.exports = seedDB;