--------------------------------------------------------------------------------------------	

			<div class="collapse navbar-collapse navbar-right">
                  <ul class="nav navbar-nav navbar-right">
					  <li><a href="/">Login</a></li>
					  <li><a href="/">Sign Up</a></li>
					  <li><a href="/">Logout</a></li>
				 </ul>
			</div>
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
app.get("/posts/:id/comments/newcomment", function(req, res){
Post.findById(req.params.id, function(err, post){
		if(err){
			console.log(err);
		}
			else{
			    res.render("comment/new.ejs", {posts: post});
		}
	});
});
app.get("/posts/:id/comments/", function(req, res){
Post.findById(req.params.id, function(err, posts){
		if(err){
			console.log(err);
		}
			else{
		Comment.find({}, function(err, comments){
		if(err){
			console.log(err);
		}
		else{
			res.render("comment/comments.ejs", {comments: comments,posts: posts});
		}
	});
}
});

});
app.post("/posts/:id/comments/", function(req, res){
	var comment = req.body.comment;
	var author = req.body.author;
	var newcomment = {comment: comment, author: author};
    Comment.create(newcomment, function(err, newlyCreatedComment){
		if(err){
			console.log(err);
		}else{
			var id = req.params.id;
			res.redirect("/posts/"+id+"/comments/");
		}
  });
});
##--------------------------------------------------------------------------------------------
 //create a comment
			    Comment.create(
					{
						comment: "Hello, Welcome you two!",
						author: "Owner of this Website.."
					},function(err, comment){
						if(err){
							console.log("OOPs!! Error, Something went wrong!!!!");
							console.log(err);
						}else{
						    post.comments.push(comment);
						    post.save();
							console.log("created new comment!!");
						}
					});
##--------------------------------------------------------------------------------------------
*Do not delete it..
*Storage like databases... :)
*Very important..
